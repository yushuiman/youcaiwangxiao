// 更改loading显示状态
export const showLoadingFlag = ({ commit }, ...args) => {
  commit('SHOWLOADINGFLAG', ...args)
}
