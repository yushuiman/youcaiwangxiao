/**
 * @method dispatchData 封装的发送commit 的函数
 */
import * as loading from 'store/actions/loading.action'

let actions = Object.assign({}, loading)

export default actions
