<template>
  <div style="text-align:center;padding:100px 0;">
    <img src="../../assets/images/zhibo/waiting.png" alt="">
    <p style="padding-top: 20px;color:#999999;">程序员哥哥努力开发中…</p>
  </div>
</template>

<script>
export default {
  data () {
    return {
    }
  },

  components: {},

  computed: {},

  mounted () {},

  methods: {}
}

</script>
<style lang='scss' scoped>
</style>
