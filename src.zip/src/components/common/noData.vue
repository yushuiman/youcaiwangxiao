<template>
  <div class="no-data-wrap">
    <div class="no-data">
      <img src="../../assets/images/global/icon_empty@3x.png" alt="">
      <p>暂无数据</p>
    </div>
    <div class="no-data">
      <img src="../../assets/images/global/icon_error@3x.png" alt="">
      <p>暂无网络</p>
    </div>
    <div class="no-data">
      <img src="../../assets/images/global/icon_nodata@3x.png" alt="">
      <p>暂无课程</p>
    </div>
  </div>
</template>

<script>
export default {
  props: {

  },
  data () {
    return {
    }
  },
  computed: {

  },
  mounted () {
  },
  methods: {

  }
}
</script>

<style scoped lang="scss" rel="stylesheet/scss">
  @import "../../assets/scss/app";

</style>
