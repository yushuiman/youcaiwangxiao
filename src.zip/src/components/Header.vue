<template>
  <div>
    <header v-if="$route.meta.showHeader">
      <div class="head-wrap">
        <div class="head-w">
          <div class="head-list">
            <img src="../assets/images/global/yc-logo.png" alt="logo" class="yc-logo fl" @click="goIndex">
            <ul class="item-list fl">
              <li :class="{'on_change': metaTitle === v.name}" v-for="(v, index) in navArr" :key="index">
                <router-link :to="v.path">{{v.name}}</router-link>
              </li>
            </ul>
          </div>
          <div class="login-wrap">
            <a class="learen-btn" @click="goLearning">学习中心</a>
            <div class="login-l fl" v-if="!this.token">
              <router-link :to="{path: 'login', query: {type:'login', is_forget: 'log-reg'}}">登录</router-link>
              <a>|</a>
              <router-link :to="{path: 'login', query: {type:'reg', is_forget: 'log-reg'}}">注册</router-link>
            </div>
            <HeadName v-if="this.token"></HeadName>
          </div>
        </div>
      </div>
      <div class="fixed-head"></div>
    </header>
  </div>
</template>
<script>
import HeadName from '../components/common/HeadName'
import { mapActions, mapState } from 'vuex'
// import config from '@/config'
export default {
  data () {
    return {
      navArr: [
        {
          path: '/',
          name: '首页'
        },
        {
          path: 'course',
          name: '课程'
        },
        {
          path: 'question',
          name: '题库'
        },
        {
          path: 'zhibo',
          name: '直播'
        },
        {
          path: 'zixun',
          name: '资讯'
        },
        {
          path: 'app',
          name: 'App'
        },
        {
          path: 'books',
          name: '优财书架'
        }
      ]
    }
  },
  computed: {
    ...mapState({
      token: state => state.user.token,
      user_id: state => state.user.user_id,
      isLoadHttpRequest: state => state.user.isLoadHttpRequest
    }),
    metaTitle () {
      return this.$route.meta.title
    }
  },
  components: {
    HeadName
  },
  mounted () {
    if (this.isLoadHttpRequest) {
      this.init()
    } else {
      this.$watch('isLoadHttpRequest', function (val, oldVal) {
        this.init()
      })
    }
  },
  methods: {
    ...mapActions([
      'handleLogOut',
      'getIndexMessage'
    ]),
    init () {
      this.getIndexMessage() // 系统消息
      var _this = this
      // var socket = io('http://ycapi.youcaiwx.com:2120')
      // var socket = io('http://apisocket.youcaiwx.com:2120')
      var socket = io('https://youcaiwx.cn:2120')
      // var socket = io(config.baseUrl.pro + ':2120')
      socket.on('connect', function () {
        socket.emit('login', _this.user_id)
      })
      // 后端推送来消息时
      socket.on('new_msg', function (msg) {
        let json = JSON.parse(msg)
        _this.$Notice.info({
          title: '您有一条新消息',
          desc: json.title
        })
        if (json.type === 'freezeMessage') {
          _this.handleLogOut()
          return
        }
        _this.getIndexMessage()
      })
    },
    goIndex () {
      this.$router.push('/')
    },
    // 学习中心
    goLearning () {
      if (this.token) {
        this.$router.push('/learning-center-detail')
      } else {
        this.$router.push('/learning-center')
      }
    }
  }
}
</script>
<style scoped lang="scss" rel="stylesheet/scss">
  @import "../assets/scss/app";
  .head-wrap{
    width: 100%;
    position: fixed;
    background: $colfff;
    z-index: 1000;
    height: 70px;
    .head-w {
      width: 1300px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin: 0 auto;
      position: relative;
    }
  }
  .fixed-head{
    height: 70px;
  }
  .yc-logo{
    @include wh(130, 34);
    margin: 18px 0;
    cursor: pointer;
  }
  .item-list{
    padding-left: 39px;
    li{
      line-height: 70px;
      font-size: 14px;
      float: left;
      box-sizing: border-box;
      a{
        padding: 0 21px;
        color: $col333;
        display: inline-block;
      }
      &.on_change{
        a {
          color: $blueColor;
        }
      }
      .tab-item{
        &.router-link-exact-active {
          color: $blueColor;
        }
      }
      &:hover{
        height: 69px;
        box-shadow:0px 0px 9px 1px rgba(193,193,193,0.54);
        border-top: 1px solid $blueColor;
        border-top-left-radius: 1px;
        border-top-right-radius: 1px;
        box-sizing: border-box;
      }
    }
  }

  .login-wrap{
    @include display_flex(flex);
    @extend %alignitem_center;
  }
  .login-l{
    color: $blueColor;
    a{
      color: $blueColor;
      float: left;
      font-size: 14px;
    }
  }
  .learen-btn{
    @include whl(100, 28, 28);
    border-radius: 14px;
    color: $colfff;
    background: $blueColor;
    margin-right: 30px;
    display: inline-block;
    text-align: center;
  }

</style>
