<template>
  <div class='prism-player' :class="{'prism-player-hide1': fixedVideo, 'prism-player-hide2': answerVideo}" :id='playerId'>
    <!-- 自定义设置 因为阿里倍速无法记忆，并且清晰度切换造成倍速无法记忆 -->
    <!-- 答疑来源小窗口answerVideo，课程、后续教育、学习计划小窗口fixedVideo -->
    <!-- diffLogic后续教育2 普通课程1 -->
    <!-- 连续播放情况，增加视频广告倒计时，但跨章播放，取消广告，增加弹窗提示，这是一个傻逼操作，给盗取视频增加困难 -->
    <div class="video-setting" :class="{'hide': fixedVideo || answerVideo}">
      <div class="setting-info">
        <div class="v-switch-item">
          <span @click.stop="switchVideo(3)">上一节</span>|<span @click.stop="switchVideo(4)">下一节</span>
        </div>
        <ul class="v-setting-ul">
          <li class="v-set-item v-set-collect" v-if="diffLogic == 2">
            <i class="set-icon collect-icon" :class="{'active': videoCredentials.collect == 1}" @click="courseCollection"></i>
          </li>
          <li class="v-set-item v-set-voice">
            <i class="set-icon voice-icon" :class="{'voice-mute-icon': isMute == 1}" @click="setVoice"></i>
            <Slider v-model="voiceNum" @on-input="onInput" style="width: 80px;height: 4px;"></Slider>
          </li>
          <li class="v-set-item v-set-quality">
            <i class="set-icon quality-icon">{{qualityTxt}}</i>
            <div class="check-set">
              <div>
                <h4>清晰度</h4>
                <p v-for="(v, index) in qualityList" :key="index" @click="setQuality(v)">
                  {{v.text}}
                  <Icon type="ios-checkmark" v-if="qualityTxt == v.text" style="font-size: 20px;position:absolute;right: 10px;top: 5px;"/>
                </p>
              </div>
            </div>
          </li>
          <li class="v-set-item v-set-speed">
            <i class="set-icon speed-icon">{{speedTxt}}</i>
            <div class="check-set">
              <div>
                <h4>倍速</h4>
                <p v-for="(v, index) in speedList" :key="index" @click="handSetSpeed(v)">
                  {{v.text}}
                  <Icon type="ios-checkmark" v-if="speedTxt == v.text" style="font-size: 20px;position:absolute;right: 10px;top: 5px;"/>
                </p>
              </div>
            </div>
          </li>
          <li class="v-set-item v-set-lianxu" v-if="diffLogic == 2">
            <span @click="setLianxuPlay" :class="{'is-lianxu': isLianxu == 1}"><Icon type="ios-checkmark" style="color:#F99111;font-weight: bold;margin-top: -3px;" v-if="isLianxu == 1" /></span>连续播放
          </li>
        </ul>
      </div>
    </div>
    <!-- 重播 -->
    <div class="set-replay" v-if="showReplay">
      <div class="wish-replay">
        <div class="cpe-integral-img" v-if="visible">
          <img v-if="gxNum == 1" src="../../assets/images/education/gx_10.png" alt="">
          <img v-if="gxNum == 2" src="../../assets/images/education/gx_20.png" alt="">
          <img v-if="gxNum == 3" src="../../assets/images/education/gx_30.png" alt="">
          <i>{{cpe_integral}}</i>
        </div>
        <a @click="replayVideo"><Icon type="md-refresh" style="font-size: 16px;margin-top: -3px;"/>重新观看</a>
        <p class="guanggao-txt" v-if="activityVisible">当前视频已播放完成，{{activityTimerNum}}s后即将进入下一个视频</p>
      </div>
    </div>
    <!-- 防止录屏，增加困难，傻逼操作 -->
    <div class="problem-operation" v-if="problemVisible">
      <div class="wish-replay">
        <p class="wish-txt">该章节已经学完了，是否要进行一下习题测试？</p>
        <div class="operation-set">
          <a @click="goDopic"><Icon type="md-brush" style="font-size: 16px;margin-top: -3px;"/>去做题</a>
          <a @click="replayVideo"><Icon type="md-refresh" style="font-size: 16px;margin-top: -3px;"/>重新观看</a>
          <a @click="computedNextVid"><Icon type="md-play" style="font-size: 16px;margin-top: -3px;"/>继续播放</a>
        </div>        
      </div>
    </div>
    <!-- 未购买，试听3分钟 -->
    <div class="try-watch-dialog" v-if="tryWatchFlag">
      <div class="wish-replay">
        <p class="wish-txt">试看结束</p>
        <div class="operation-set">
          <a @click="goBuy"><Icon type="md-cart" style="font-size: 16px;margin-top: -3px;"/>去购买</a>
          <a @click="replayVideo"><Icon type="md-refresh" style="font-size: 16px;margin-top: -3px;"/>重新观看</a>
        </div>        
      </div>
    </div>
    <!-- 后续教育签到 -->
    <div class="sign-box" v-if="canSign && visible">
      <div class="opa"></div>
      <div class="sign-cont">
        <p>签到获得本课程CPE积分</p>
        <button class="btn-com" @click="signSub">签到</button>
        <!-- <span>{{jianTime}}秒之后关闭～</span> -->
      </div>
    </div>
    <!-- 后续教育禁止拖拽进度条 -->
    <!-- <div class="progress-bar" v-if="diffLogic == 1"></div> -->
    <!-- 视频水印 -->
    <!-- <div class="shuiyin-wrap">
      <div class="shuiyin">优财网校{{user_id}}</div>
      <div class="shuiyin">优财网校{{user_id}}</div>
      <div class="shuiyin">优财网校{{user_id}}</div>
      <div class="shuiyin">优财网校{{user_id}}</div>
    </div> -->
  </div>
</template>
<script>
import Cookies from 'js-cookie'
export default {
  name: 'Aliplayer',
  props: {
    answerVideo: {
      type: Boolean,
      default: false
    },
    fixedVideo: {
      type: Boolean,
      default: false
    },
    videoCredentials: {
      type: Object
    },
    isLianxu: {
      type: Number,
      default: 1
    },
    showReplay: {
      type: Boolean,
      default: false
    },
    activityVisible: {
      type: Boolean,
      default: false
    },
    activityTimerNum: {
      type: Number
    },
    problemVisible: {
      type: Boolean,
      default: false
    },
    tryWatchFlag: {
      type: Boolean,
      default: false
    },
    cpe_integral: {
      type: Number
    },
    // 后续教育
    jianTime: {
      type: Number
    },
    visible: {
      type: Boolean,
      default: false
    },
    canSign: {
      type: Boolean,
      default: false
    },
    diffLogic: {
      type: Number,
      default: 2
    },
    // 后续教育结束
    user_id: {
      type: Number
    },
    aliplayerSdkPath: {
      type: String,
      default: 'https://g.alicdn.com/de/prismplayer/2.9.1/aliplayer-min.js'
    },
    autoplay: {
      type: Boolean,
      default: true
    },
    isLive: {
      type: Boolean,
      default: false
    },
    playsinline: {
      type: Boolean,
      default: false
    },
    width: {
      type: String,
      default: '100%'
    },
    height: {
      type: String,
      default: '100%'
    },
    controlBarVisibility: {
      type: String,
      default: 'hover'
    },
    useH5Prism: {
      type: Boolean,
      default: false
    },
    useFlashPrism: {
      type: Boolean,
      default: false
    },
    vid: {
      type: String,
      default: ''
    },
    playauth: {
      type: String,
      default: ''
    },
    playtime: {
      type: Number,
      default: 0
    },
    cover: {
      type: String,
      default: ''
    },
    format: {
      type: String,
      default: 'mp4'
    },
    x5_video_position: {
      type: String,
      default: 'top'
    },
    x5_type: {
      type: String,
      default: 'mp4'
    },
    x5_fullscreen: {
      type: Boolean,
      default: false
    },
    x5_orientation: {
      type: Number,
      default: 2
    },
    autoPlayDelay: {
      type: Number,
      default: 0
    },
    autoPlayDelayDisplayText: {
      type: String
    },
    endPlay: {
      type: Boolean,
      default: true
    },
    liveSkin: [
      {
        name: 'bigPlayButton',
        align: 'blabs',
        x: 30,
        y: 80
      },
      {
        name: 'errorDisplay',
        align: 'tlabs',
        x: 0,
        y: 0
      },
      {
        name: 'infoDisplay'
      },
      {
        name: 'controlBar',
        align: 'blabs',
        x: 0,
        y: 0,
        children: [
          {
            name: 'liveDisplay',
            align: 'tlabs',
            x: 15,
            y: 25
          },
          {
            name: 'fullScreenButton',
            align: 'tr',
            x: 10,
            y: 25
          },
          {
            name: 'volume',
            align: 'tr',
            x: 10,
            y: 25
          }
        ]
      }
    ],
    playSkin: [
      {
        name: 'bigPlayButton',
        align: 'blabs',
        x: 30,
        y: 80
      },
      {
        name: 'controlBar',
        align: 'blabs',
        x: 0,
        y: 0,
        children: [
          {
            name: 'progress',
            align: 'tlabs',
            x: 0,
            y: 0
          },
          {
            name: 'playButton',
            align: 'tl',
            x: 15,
            y: 26
          },
          {
            name: 'nextButton',
            align: 'tl',
            x: 10,
            y: 26
          },
          {
            name: 'timeDisplay',
            align: 'tl',
            x: 10,
            y: 24
          },
          {
            name: 'fullScreenButton',
            align: 'tr',
            x: 10,
            y: 25
          },
          {
            name: 'streamButton',
            align: 'tr',
            x: 10,
            y: 23
          },
          {
            name: 'volume',
            align: 'tr',
            x: 10,
            y: 25
          }
        ]
      },
      {
        name: 'fullControlBar',
        align: 'tlabs',
        x: 0,
        y: 0,
        children: [
          {
            name: 'fullTitle',
            align: 'tl',
            x: 25,
            y: 6
          },
          {
            name: 'fullNormalScreenButton',
            align: 'tr',
            x: 24,
            y: 13
          },
          {
            name: 'fullTimeDisplay',
            align: 'tr',
            x: 10,
            y: 12
          },
          {
            name: 'fullZoom',
            align: 'cc'
          }
        ]
      }
    ],
    skinLayout: [
      {name: "bigPlayButton", align: "blabs", x: 30, y: 80},
      {name: "errorDisplay", align: "tlabs", x: 0, y: 0},
      {name: "infoDisplay", align: "cc"},
      {
        name: "controlBar", align: "blabs", x: 0, y: 0,
        children: [
            {name:"liveDisplay", align:"tlabs", x: 15, y:6},
            {name:"fullScreenButton", align:"tr", x:10, y: 10},
            {name:"subtitle", align:"tr",x:15, y:12},
            {name:"setting", align:"tr",x:15, y:12},
            {name:"volume", align:"tr", x:5, y:10}
          ]
      }
    ]
  },
  // inject: ['reload'],
  data () {
    return {
      gxNum: Math.floor(Math.random() * 3) + 1,
      playerId: 'aliplayer_' + Math.floor(Math.random() * 100000000000000000),
      scriptTagStatus: 0,
      isReload: false,
      instance: null,
      speedTxt: Cookies.get('speedTxt') || '正常',
      qualityTxt: Cookies.get('qualityTxt') || '流畅',
      voiceNum: parseInt(Cookies.get('voicenum')) || 100, // 音量
      voiceNum1: parseInt(Cookies.get('voicenum1')) || 100, // 音量
      speedList: [
        {
          text: '0.5X',
          speednum: 0.5
        },
        {
          text: '0.8X',
          speednum: 0.8
        },
        {
          text: '正常',
          speednum: 1
        },
        {
          text: '1.25X',
          speednum: 1.25
        },
        {
          text: '1.5X',
          speednum: 1.5
        },
        {
          text: '2X',
          speednum: 2
        }
      ],
      qualityList: [
        {
          text: '流畅',
          type: 'FD'
        },
        {
          text: '标清',
          type: 'LD'
        },
        {
          text: '高清',
          type: 'SD'
        }
      ],
      isMute: 2, // 1静音2正常
      // isLianxu: Cookies.get('isLianxu') || true, // 是否连续播放
      // showReplay: false // 连续播放按钮
      animationTimer: null
    }
  },
  mounted () {
    // this.animationTimerSet()
    if (window.Aliplayer !== undefined) {
      // 如果全局对象存在，说明编辑器代码已经初始化完成，直接加载编辑器
      this.scriptTagStatus = 2
      this.initAliplayer()
    } else {
      // 如果全局对象不存在，说明编辑器代码还没有加载完成，需要加载编辑器代码
      this.insertScriptTag()
    }
  },
  created () {
    if (window.Aliplayer !== undefined) {
      // 如果全局对象存在，说明编辑器代码已经初始化完成，直接加载编辑器
      this.scriptTagStatus = 2
      window.onload = function () {
        this.initAliplayer()
      }
    } else {
      // 如果全局对象不存在，说明编辑器代码还没有加载完成，需要加载编辑器代码
      this.insertScriptTag()
    }
  },
  methods: {
    animationTimerSet () {
      this.animationTimer = setInterval(() => {
        var oDiv = document.createElement('div')
        var yDiv = document.querySelector('.prism-player')
        oDiv.className = "animation-box animate"
        oDiv.innerHTML = '优财网校' + this.user_id
        yDiv.appendChild(oDiv)
        // 页面载入时，给它执行一次
        // 监听动画是否结束 animation: mymove 5s;
        setTimeout (() => {
          yDiv.removeChild(oDiv)
        }, 5000)
        // yDiv.addEventListener ('animationend', function () {
        //   // 动画结束，移除动画的样式类
        //   console.log(yDiv)
        //   setTimeout (() => {
        //     yDiv.removeChild(oDiv)
        //     console.log('removeChild')
        //   }, 10)
        // })
      }, 300000) // 5分钟一次
    },
    insertScriptTag () {
      const _this = this
      let playerScriptTag = document.getElementById('playerScriptTag')
      // 如果这个tag不存在，则生成相关代码tag以加载代码
      if (playerScriptTag === null) {
        playerScriptTag = document.createElement('script')
        playerScriptTag.type = 'text/javascript'
        playerScriptTag.src = this.aliplayerSdkPath
        playerScriptTag.id = 'playerScriptTag'
        let s = document.getElementsByTagName('head')[0]
        s.appendChild(playerScriptTag)
      }
      if (playerScriptTag.loaded) {
        _this.scriptTagStatus++
      } else {
        playerScriptTag.addEventListener('load', () => {
          _this.scriptTagStatus++
          playerScriptTag.loaded = true
          _this.initAliplayer()
        })
      }
      _this.initAliplayer()
    },
    initAliplayer () {
      const _this = this
      // scriptTagStatus 为 2 的时候，说明两个必需引入的 js 文件都已经被引入，且加载完成
      if (_this.scriptTagStatus === 2 && (_this.instance === null || _this.reloadPlayer)) {
        _this.instance && _this.instance.dispose()
        _this.$nextTick(() => {
          _this.instance = window.Aliplayer({
            id: _this.playerId,
            // source: _this.playauth,
            // source: 'https://video.youcaiwx.com/5b614e07acd846f09b8bf273c5bedcfd/2789e14b2d0b419c8561ccffe34f7d46-d21f83fc069d251d30fa70bf9329c887-fd-encrypt-stream.m3u8?MtsHlsUriToken=gdt+Iz+Ze4dR/b7sd6Cdr82ZRUO4ToW+9bf55YxTpa8=',
            // source: 'http://demo.com/ddf56e501d07402796c468bbea08ec8c/9e712e72879b93f8933d5f9eca4bacaa-fd-encrypt-stream.m3u8?MtsHlsUriToken=NWItZGU5ZWEwODRlMzky',
            autoplay: _this.autoplay,
            isLive: _this.isLive,
            playsinline: _this.playsinline,
            width: _this.width,
            height: _this.height,
            controlBarVisibility: _this.controlBarVisibility,
            useH5Prism: _this.useH5Prism,
            useFlashPrism: _this.useFlashPrism,
            vid: _this.videoCredentials.VideoId,
            playauth: _this.videoCredentials.playAuth,
            format: _this.videoCredentials.format,
            encryptType: 1,
            cover: _this.cover,
            x5_video_position: _this.x5_video_position,
            x5_type: _this.x5_type,
            x5_fullscreen: _this.x5_fullscreen,
            x5_orientation: _this.x5_orientation,
            autoPlayDelay: _this.autoPlayDelay,
            components: [{
              name: 'BulletScreenComponent',
              type: AliPlayerComponent.BulletScreenComponent,
              /** Descriptions of the scrolling text component parameters: text, style, bulletPosition 
              * text: The scrolling text
              * style: The style of the scrolling text
              * bulletPosition: The position of the scrolling text. Valid values: 'top', 'bottom', and 'random'. The default is 'random'.
              */
              args: ['优财网校' + this.user_id, {fontSize: '14px', fontWeight: 'bold', color: '#c8c8c8'}, 'random']
            }]
          })
          // 绑定事件，当 AliPlayer 初始化完成后，将编辑器实例通过自定义的 ready 事件交出去
          var _video = document.querySelector('video')
          _this.instance.on('ready', () => {
            this.$emit('ready', _this.instance)
          })
          _this.instance.on('play', () => {
            // 暂停和拖拽冲突了
            if (!this.answerVideo) {
              _video.removeEventListener('click', this.play)
              _video.addEventListener('click', this.pause)
            }
            this.$emit('play', _this.instance)
          })
          _this.instance.on('pause', () => {
            if (!this.answerVideo) {
              _video.removeEventListener('click', this.pause)
              _video.addEventListener('click', this.play)
            }
            this.$emit('pause', _this.instance)
          })
          _this.instance.on('ended', () => {
            this.$emit('ended', _this.instance)
          })
          _this.instance.on('liveStreamStop', () => {
            this.$emit('liveStreamStop', _this.instance)
          })
          _this.instance.on('m3u8Retry', () => {
            this.$emit('m3u8Retry', _this.instance)
          })
          _this.instance.on('hideBar', () => {
            this.$emit('hideBar', _this.instance)
          })
          _this.instance.on('waiting', () => {
            this.$emit('waiting', _this.instance)
          })
          _this.instance.on('snapshoted', () => {
            this.$emit('snapshoted', _this.instance)
          })
          _this.instance.on('dispose', () => {
            this.$emit('dispose', _this.instance)
          })
        })
      }
    },
    /**
       * 视频结束
       */
    ended: function () {
      // var _this = this
      this.instance.replayByVidAndPlayAuth(this.videoCredentials.VideoId, this.videoCredentials.playAuth)
    },
    /**
       * 销毁
       */
    dispose: function () {
      this.instance.dispose()
    },
    /**
       * 播放视频
       */
    play: function () {
      this.instance.play()
    },
    /**
       * 暂停视频
       */
    pause: function () {
      this.instance.pause()
    },
    /**
       * 重播视频
       */
    replay: function () {
      this.instance.replay()
    },
    /**
       * 跳转到某个时刻进行播放
       * @argument time 的单位为秒
       */
    seek: function (time) {
      this.instance.seek(time)
    },
    /**
       * 获取当前时间 单位秒
       */
    getCurrentTime: function () {
      return this.instance.getCurrentTime()
    },
    /**
     * 获取视频状态
     */
    getStatus: function () {
      return this.instance.getStatus()
    },
    /**
       *获取视频总时长，返回的单位为秒
       * @returns 返回的单位为秒
       */
    getDuration: function () {
      return this.instance.getDuration()
    },
    /**
       获取当前的音量，返回值为0-1的实数ios和部分android会失效
       */
    getVolume: function () {
      return this.instance.getVolume()
    },
    /**
       设置音量，vol为0-1的实数，ios和部分android会失效
       */
    setVolume: function (vol) {
      this.instance.setVolume(vol)
    },
    /**
       *直接播放视频url，time为可选值（单位秒）目前只支持同种格式（mp4/flv/m3u8）之间切换暂不支持直播rtmp流切换
       *@argument url 视频地址
       *@argument time 跳转到多少秒
       */
    loadByUrl: function (url, time) {
      this.instance.loadByUrl(url, time)
    },
    /**
       * 设置播放速度
       *@argument speed 速度
       */
    setSpeed: function (speed) {
      this.instance.setSpeed(speed)
    },
    /**
       * 设置播放器大小w,h可分别为400px像素或60%百分比chrome浏览器下flash播放器分别不能小于397x297
       *@argument w 播放器宽度
       *@argument h 播放器高度
       */
    setPlayerSize: function (w, h) {
      this.instance.setPlayerSize(w, h)
    },
    /**
       * 目前只支持HTML5界面上的重载功能,暂不支持直播rtmp流切换m3u8）之间切换,暂不支持直播rtmp流切换
       *@argument vid 视频id
       *@argument playauth 播放凭证
       */
    reloaduserPlayInfoAndVidRequestMts: function (vid, playauth) {
      this.instance.reloaduserPlayInfoAndVidRequestMts(vid, playauth)
    },
    reloadPlayer: function () {
      this.isReload = true
      this.initAliplayer()
      this.isReload = false
    },
    // 设置声音
    keySetVoice () {
      this.voiceNum = parseInt(Cookies.get('voicenum'))
    },
    setVoice () {
      this.voiceNum = parseInt(Cookies.get('voicenum'))
      this.voiceNum1 = parseInt(Cookies.get('voicenum1'))
      // 1静音2正常
      if (this.isMute == 1) {
        this.isMute = 2
        // if (this.voiceNum == 0) {
        //   this.voiceNum = this.voiceNum || 100
        // } else {
        // }
        this.voiceNum = this.voiceNum1 || 100
        this.instance.setVolume(this.voiceNum1 / 100)
        return
      }
      if (this.isMute == 2) {
        this.isMute = 1
        this.voiceNum = 0
        this.instance.setVolume(0)
        Cookies.set('voicenum', this.voiceNum1)
        Cookies.set('voicenum1', this.voiceNum1)
      }
    },
    onInput () {
      this.instance.setVolume(this.voiceNum / 100)
      if (this.voiceNum == 0) {
        this.isMute = 1
        Cookies.set('voicenum', this.voiceNum)
        return
      }
      Cookies.set('voicenum', this.voiceNum)
      Cookies.set('voicenum1', this.voiceNum)
      this.isMute = 2
    },
    // 设置清晰度
    setQuality ({ text, type }) {
      this.qualityTxt = text
      Cookies.set('qualityTxt', text)
      Cookies.set('selectedStreamLevel', type)
      // document.querySelector('.check-set').style.display = 'none'
      // this.reload()
      // this.$emit('switchQuality')
      this.$emit('switchVideo', 1)
    },
    // 设置倍速
    handSetSpeed ({ text, speednum }) {
      this.speedTxt = text
      Cookies.set('speedTxt', text)
      Cookies.set('speednum', speednum)
      this.instance.setSpeed(speednum)
      // document.querySelector('.check-set').style.display = 'none'
    },
    // 收藏
    courseCollection () {
      this.$emit('courseCollection')
    },
    // 是否连续播放
    // checkLianxuChange (val) {
    //   this.$emit('setLianxuPlay', false)
    // },
    setLianxuPlay () {
      if (this.isLianxu == 1) {
        this.$emit('setLianxuPlay', 2)
      } else {
        this.$emit('setLianxuPlay', 1)
      }
    },
    // 重新观看
    replayVideo () {
      this.$emit('replayVideo')
    },
    // 下一节
    computedNextVid () {
      this.$emit('computedNextVid', 1)
    },
    // 去题库
    goDopic () {
      this.$router.push('/question')
    },
    // 去购买
    goBuy () {
      this.$router.push({ path: '/course-detail',
        query: {
          package_id: this.$route.query.package_id
        }
      })
    },
    switchVideo (type) {
      this.$emit('switchVideo', type)
    },
    // 签到
    signVisible (val) {
      if (!val) {
        this.$emit('update:visible', false)
        this.$emit('update:canSign', false)
      }
    },
    signSub () {
      this.$emit('signSub', false)
    }
  },
  beforeDestroy () {
    clearInterval(this.animationTimer)
    this.animationTimer = null
  }
}
</script>

<style>
  @import url('https://g.alicdn.com/de/prismplayer/2.9.1/skins/default/aliplayer-min.css');
  @import "../../assets/scss/aliplayer.css";
  .prism-player .prism-progress .prism-progress-played{
    background: #F99111!important;
  }
  .prism-player .prism-progress:hover{
    height: 10px!important;
  }
  .prism-progress-cursor{
    background: none!important;
    display: none!important;
  }
  .prism-progress-cursor img, .cursor-hover img{
    display: none!important;
  }
  .prism-player .prism-progress{
    background: #000000!important;
  }
  .prism-player .prism-progress .prism-progress-loaded{
    background: #4A4A4A!important;
  }
  .prism-player .prism-play-btn.playing:hover {
    background: url('../../assets/images/video/smallpausehover.png') no-repeat;
    background-size: contain;
  }
  /* .prism-player .prism-play-btn,.prism-player .prism-play-btn:hover{
    background: url('../../assets/images/video/play-btn-hover-icon.png') no-repeat;
    background-size: contain;
  } */
  .prism-player .prism-big-play-btn{
    top: 50%!important;
    left: 50%!important;
    margin-top: -32px!important;
    margin-left: -32px!important;
  }
  /* .prism-player .prism-play-btn.playing{
    background: url('../../assets/images/video/play-stop-m.png') no-repeat;
    background-size: contain;
  }
  .prism-player .prism-setting-btn{
    background: url('../../assets/images/video/play-set-m.png') no-repeat;
    background-size: contain;
  }
  .prism-player .prism-volume .volume-icon .long-horizontal,.prism-player .prism-volume .volume-icon .short-horizontal{
    box-shadow: 0 0 1px #000;
  }
  .prism-player .prism-fullscreen-btn{
    background: url('../../assets/images/video/play-screen-m.png') no-repeat;
    background-size: contain;
  } */
  /* .prism-player .prism-volume .volume-icon{
    background: url('../../assets/images/video/play-voice-m.png') no-repeat;
    background-size: contain;
  }
  .prism-player .prism-volume-control{
    background: none;
  }
  .prism-player .prism-volume-control .volume-value{
    background: #F99111;
  }
  .prism-player .prism-volume-control .volume-cursor{
    background: #999999;
  }
  .prism-player .prism-volume-control .volume-cursor:hover{
    background: #F99111;
  } */
  /* .prism-player .prism-volume .volume-icon:hover{
    background: url('../../assets/images/video/volumehover.png') no-repeat;
    background-size: contain;
  } */
  /* .prism-player .prism-volume .volume-icon.mute{
    background: url('../../assets/images/video/volumemutehover.png') no-repeat;
    background-size: contain;
  }
  .prism-player .prism-volume .volume-icon.mute:hover{
    background: url('../../assets/images/video/volumemutehover.png') no-repeat;
    background-size: contain;
  }
  .prism-volume{
    margin-right: 15px!important;
  }
  .prism-cc-btn{
    display: none;
  }
  .prism-player .prism-setting-list .prism-setting-cc, .prism-player .prism-setting-list .prism-setting-audio{
    display: none;
  }
  .prism-player .prism-time-display .current-time, .prism-player .prism-time-display{
    color: #cccccc;
    text-shadow:#000 1px 0 0,#000 0 1px 0,#000 -1px 0 0,#000 0 -1px 0;
    -webkit-text-shadow:#000 1px 0 0,#000 0 1px 0,#000 -1px 0 0,#000 0 -1px 0;
    -moz-text-shadow:#000 1px 0 0,#000 0 1px 0,#000 -1px 0 0,#000 0 -1px 0;
  }
  .prism-player .prism-time-display .current-time{
    color: #ffffff;
  } */
  /* 封面图 */
  .prism-player .prism-cover{
    z-index: 13;
  }
  /* video被进度条遮挡 */
  .prism-player video{
    padding-bottom: 44px;
  }
  .prism-player-hide1 video, .prism-player-hide2 video{
    padding-bottom: 0;
  }
  /* 设置icon 隐藏 */
  /* .prism-player .prism-fullscreen-btn, */
  .prism-player .prism-volume,.prism-player .prism-cc-btn,.prism-player .prism-setting-btn,.prism-player .prism-volume{
    display: none;
  }
  .prism-player .prism-info-left-bottom{display:none!important;}
  .prism-player-hide1 .prism-fullscreen-btn, .prism-player-hide2 .prism-fullscreen-btn {display:none;}
  /* .prism-player-hide2 .prism-progress, .prism-player-hide2 .prism-time-display, .prism-player-hide2 .prism-fullscreen-btn {display:none;} */
  /* 诊断 隐藏*/
  .prism-player .prism-ErrorMessage .prism-error-operation a.prism-button-orange{
    display: none;
  }
  /* 自定义icon */
  /* 水印 */
  /* .shuiyin-wrap .shuiyin{
    position: absolute;
    left: 10%;
    top: 25%;
    transform: rotate(-35deg);
    color: rgba(200, 200, 200, 0.5);
    font-weight: bold;
  }
  .shuiyin-wrap .shuiyin:nth-child(2){
    left: 10%;
    top: 82%;
  }
  .shuiyin-wrap .shuiyin:nth-child(3){
    left: 80%;
    top: 25%;
  }
  .shuiyin-wrap .shuiyin:nth-child(4){
    left: 82%;
    top: 82%;
  } */
  /* 签到 */
  .sign-box .opa{
    /* position: fixed; */
    z-index: 1001;
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,.6);
  }
  .sign-cont{
    /* position: fixed; */
    z-index: 1002;
    position: absolute;
    width: 240px;
    left: 50%;
    top: 50%;
    border-radius: 4px;
    transform: translate(-50%, -50%);
    background: #ffffff;
    text-align: center;
    padding: 20px;
  }
  .sign-cont p{
    font-size: 16px;
  }
  /* 一天晃荡几百遍 */
  .sign-cont button{
    width: 65px;
    height: 26px;
    background: #1874FD;
    color: #ffffff;
    margin-top: 20px;
  }
  .sign-cont span{
    display: block;
    margin-top: 5px;
    color: #999999;
  }
  /* 进度条遮挡 */
  .progress-bar{
    position: absolute;
    left: 0;
    bottom: 39px;
    width: 100%;
    height: 12px;
    z-index: 11;
  }
  /* 5分钟一次跑马灯 */
  .slide-fade-enter-active {
    animation: mymove 5s;
  }
  .slide-fade-leave-active {
    animation: mymove 5s reverse;
  }
  .animation-box {
    color: rgba(200, 200, 200, 0.5);
    font-weight: bold;
    position: absolute;
  }
  .animation-box.animate{
    animation: mymove 5s;
    -webkit-animation: mymove 5s; /*Safari and Chrome*/
    /* transform: rotate(15deg); */
  }
  @keyframes mymove
  {
  from {left:0px;top: 0;}
  to {left:90%;top: 100%;}
  }

  @-webkit-keyframes mymove /*Safari and Chrome*/
  {
  from {left:0px;top: 0;}
  to {left:90%;top:100%;}
  }
</style>
